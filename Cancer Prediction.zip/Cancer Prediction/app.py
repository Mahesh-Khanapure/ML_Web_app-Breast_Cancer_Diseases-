from flask import Flask, render_template, request
import pickle
import numpy as np

app = Flask(__name__,static_url_path='/static')

# Load the machine learning model
model = pickle.load(open('B_cancer.pkl', 'rb'))


@app.route('/')
def home():
    return render_template('index.html')
@app.route('/predict', methods=['POST'])
def predict():
    # Get the user input
    prediction_class = ""
    prediction_message = ""
    radius_mean = float(request.form.get("1"))
    area_mean = float(request.form.get("2"))
    compactness_mean = float(request.form.get("3"))
    concavity_mean = float(request.form.get("4"))
    concave_points_mean = float(request.form.get("5"))
    area_worst = float(request.form.get("6"))
    compactness_worst=float(request.form.get("7"))
    concavity_worst=float(request.form.get("8"))
    area_se = float(request.form.get("9"))
    fractal_dimension_se = float(request.form.get("10"))
    symmetry_worst = float(request.form.get("11"))
    fractal_dimension_worst = float(request.form.get("12"))
    

    
    user_input = [radius_mean, area_mean, compactness_mean, concavity_mean, concave_points_mean, area_worst,compactness_worst,concavity_worst, area_se, fractal_dimension_se, 
                  symmetry_worst,fractal_dimension_worst]

    # Make a prediction using the loaded model
    prediction = model.predict(np.array(user_input).reshape(1, -1))
    print(prediction)

    if prediction[0] == 1:
        prediction_class = "red"
        prediction_message = "The patient does not have Malignant."
    else:
        prediction_class = "green"
        prediction_message = "The patient has Benign."

    return render_template("result.html", prediction_message=prediction_message, prediction_class=prediction_class,
                           user_input=user_input)


if __name__ == "__main__":
    app.run(debug=True, port=5200)